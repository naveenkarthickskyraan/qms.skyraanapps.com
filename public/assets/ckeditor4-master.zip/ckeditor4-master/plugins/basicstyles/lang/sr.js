/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'sr', {
	bold: 'Подебљано',
	italic: 'Курзив',
	strike: 'Прецртано',
	subscript: 'Индекс',
	superscript: 'Степен',
	underline: 'Подвучено'
} );
